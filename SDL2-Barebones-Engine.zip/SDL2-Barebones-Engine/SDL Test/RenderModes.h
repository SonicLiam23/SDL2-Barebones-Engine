#pragma once

enum RenderMode
{
	SINGLE_IMG,
	ANIMATION,
	DO_NOT_RENDER
};


class RenderModes
{
};

