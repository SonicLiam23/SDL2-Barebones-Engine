#pragma once
struct Globals
{
	static const int SCREEN_SIZE_X = 1280;
	static const int SCREEN_SIZE_Y = 720;
	static const int MAX_OBJECTS = 100;
	static const int MAX_TEXT_RENDERERS = 20;
};

