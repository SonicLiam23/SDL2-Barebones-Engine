#include "GameManager.h"
#include "BMPRenderer.h"

int main(int argc, char* argv[]) 
{ 
	// creates the SDL2 engine and inits it all etc
	GameManager G;
	G.Init();
	// Adds an image using the renderer created by GameManager
	// Same code from project from last year
	G.GetBMPRenderer()->AddImage("grid.bmp");

	return 0;
}